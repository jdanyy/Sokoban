package Map;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Board extends JPanel {
    private final int OFFSET = 40;
    private final int DIFF = 40;
    private final int L_COLLISION = 1;
    private final int R_COLLISION = 2;
    private final int T_COLLISION = 3;
    private final int B_COLLISION = 4;
    private ArrayList<Destination> destinations;
    private ArrayList<Wall> walls;
    private ArrayList<Baggage> baggages;
    private Player player;
    private int width;
    private int height;
    private String level;
    private boolean Completed;
    private Color color;
    public Board (String level){
        this.addKeyListener(new KAdapter());
        this.setFocusable(true);

        this.level = level;
        width = 0;
        height = 0;
        color = new Color(0xECB07E);

        initializeBoard();
    }
    public void initializeBoard(){
        destinations = new ArrayList<>();
        walls = new ArrayList<>();
        baggages = new ArrayList<>();

        this.requestFocusInWindow();
        Completed = false;

        int x = OFFSET;
        int y = OFFSET;

        Wall wall;
        Baggage baggage;
        Destination destination;

        for (int i = 0; i < level.length(); i++){
            char step = level.charAt(i);

            switch (step) {
                case '\n':
                    y += DIFF;

                    if (this.width < x){
                        this.width = x;
                    }
                    x = OFFSET;
                    break;
                case '#':
                    wall = new Wall(x, y);
                    walls.add(wall);
                    x += DIFF;
                    break;
                case '$':
                    baggage = new Baggage(x, y);
                    baggages.add(baggage);
                    x += DIFF;
                    break;
                case '.':
                    destination = new Destination(x, y);
                    destinations.add(destination);
                    x += DIFF;
                    break;
                case '@':
                    player = new Player(x, y);
                    x += DIFF;
                    break;
                case ' ':
                    x += DIFF;
                    break;
                default: break;
            }
            height = y;
        }
    }

    public int getBoardWidth(){
        return this.width;
    }

    public int getBoardHeight(){
        return this.height;
    }
    public Color getColor() { return this.color; }
    public Boolean getCompleted () { return this.Completed; }
    public void isCompleted(){
        int numberOfBags = baggages.size();
        int finishBags = 0;

        for (int i = 0; i < numberOfBags; i++){
            Baggage baggage = baggages.get(i);

            for (int j = 0; j < numberOfBags; j++){
                Destination destination = destinations.get(j);

                if (baggage.getX() == destination.getX() && baggage.getY() == destination.getY()){
                    finishBags += 1;
                }
            }
        }

        if (finishBags == numberOfBags){
            Completed = true;
            repaint();
        }
    }
    private void buildWorld (Graphics g) {

        g.setColor(color);
        g.fillRect(0, 0,900, 700);

        ArrayList<Item> world = new ArrayList<>();
        world.addAll(destinations);
        world.addAll(baggages);
        world.addAll(walls);
        world.add(player);

        for (int i = 0; i < world.size(); i++) {
            Item item = world.get(i);

            if (Player.class.isInstance(item) || Baggage.class.isInstance(item) || Destination.class.isInstance(item)) {
                g.drawImage(item.getImage(), item.getX(), item.getY(), this);
            } else {
                g.drawImage(item.getImage(), item.getX() , item.getY() , this);
            }

            if (Completed){
                g.fillRect(getBoardWidth() / 2 - OFFSET, getBoardHeight() / 2 -  OFFSET, 150, 150);
                try {
                    g.drawImage(ImageIO.read(new File("res/img/completed.png")), getBoardWidth() / 2 -   OFFSET, getBoardHeight() / 2 -  OFFSET, this);
                } catch (IOException e){
                    e.printStackTrace();
                    System.exit(-2);
                }
            }
        }
    }

    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        buildWorld(g);
    }
    private boolean checkWallCollision (Item item, int type){
        switch (type){
            case L_COLLISION:
                for (int i = 0; i < walls.size(); i++){
                    Wall wall = walls.get(i);
                    if (item.leftCollision(wall)){
                        return true;
                    }
                }
                break;
            case T_COLLISION:
                for (int i = 0; i < walls.size(); i++){
                    Wall wall = walls.get(i);
                    if (item.topCollision(wall)){
                        return true;
                    }
                }
                break;
            case R_COLLISION:
                for (int i = 0; i < walls.size(); i++){
                    Wall wall = walls.get(i);
                    if (item.rightCollision(wall)){
                        return true;
                    }
                }
                break;
            case B_COLLISION:
                for (int i = 0; i < walls.size(); i++){
                    Wall wall = walls.get(i);
                    if (item.bottomCollision(wall)){
                        return true;
                    }
                }
                break;
            default: break;
        }

        return false;
    }
    private boolean checkBaggageCollision (int type){
        switch (type){
            case L_COLLISION:
                for (int i = 0; i < baggages.size(); i++){
                    Baggage baggage = baggages.get(i);
                    if (player.leftCollision(baggage)){

                        if (checkWallCollision(baggage, L_COLLISION)){
                            return true;
                        }

                        for (int j = 0; j < baggages.size(); j++){
                            Baggage baggage1 = baggages.get(j);

                            if (!baggage.equals(baggage1)){
                                if (baggage.leftCollision(baggage1)){
                                    return true;
                                }
                            }
                        }
                        baggage.move(-DIFF, 0);
                        isCompleted();
                    }
                }
                break;
            case T_COLLISION:
                for (int i = 0; i < baggages.size(); i++){
                    Baggage baggage = baggages.get(i);
                    if (player.topCollision(baggage)){

                        if (checkWallCollision(baggage, T_COLLISION)){
                            return true;
                        }

                        for (int j = 0; j < baggages.size(); j++){
                            Baggage baggage1 = baggages.get(j);

                            if (!baggage.equals(baggage1)){
                                if (baggage.topCollision(baggage1)){
                                    return true;
                                }
                            }
                        }

                        baggage.move(0, -DIFF);
                        isCompleted();
                    }
                }
                break;
            case R_COLLISION:
                for (int i = 0; i < baggages.size(); i++){
                    Baggage baggage = baggages.get(i);
                    if (player.rightCollision(baggage)) {

                        if (checkWallCollision(baggage, R_COLLISION)) {
                            return true;
                        }

                        for (int j = 0; j < baggages.size(); j++) {
                            Baggage baggage1 = baggages.get(j);

                            if (!baggage.equals(baggage1)) {
                                if (baggage.rightCollision(baggage1)) {
                                    return true;
                                }
                            }
                        }

                        baggage.move(DIFF, 0);
                        isCompleted();
                    }
                }
                break;
            case B_COLLISION:
                for (int i = 0; i < baggages.size(); i++){
                    Baggage baggage = baggages.get(i);
                    if (player.bottomCollision(baggage)){

                        if (checkWallCollision(baggage,B_COLLISION)){
                            return true;
                        }

                        for (int j = 0; j < baggages.size(); j++){
                            Baggage baggage1 = baggages.get(j);

                            if (!baggage.equals(baggage1)){
                                if (baggage.bottomCollision(baggage1)){
                                    return true;
                                }
                            }
                        }
                        baggage.move(0, DIFF);
                        isCompleted();
                    }
                }
                break;
            default: break;
        }
        return false;
    }
    private class KAdapter extends KeyAdapter{
        @Override
        public void keyPressed(KeyEvent e){

            if (Completed){
                return;
            }

            int key = e.getKeyCode();
            switch (key){
                case KeyEvent.VK_LEFT:
                    if (checkWallCollision(player, L_COLLISION)){
                        return;
                    }

                    if (checkBaggageCollision(L_COLLISION)){
                        return;
                    }

                    player.move(-DIFF, 0);
                    break;
                case KeyEvent.VK_UP:
                    if (checkWallCollision(player, T_COLLISION)){
                        return;
                    }
                    if (checkBaggageCollision(T_COLLISION)){
                        return;
                    }

                    player.move(0, -DIFF);
                    break;

                case KeyEvent.VK_RIGHT:
                    if (checkWallCollision(player, R_COLLISION)){
                        return;
                    }

                    if (checkBaggageCollision(R_COLLISION)){
                        return;
                    }

                    player.move(DIFF, 0);
                    break;
                case KeyEvent.VK_DOWN:
                    if (checkWallCollision(player, B_COLLISION)){
                        return;
                    }
                    if (checkBaggageCollision(B_COLLISION)){
                        return;
                    }

                    player.move(0, DIFF);
                    break;
                case KeyEvent.VK_R:
                    restartLevel();
                    break;
                default: break;
            }
            repaint();
        }
    }
    public void restartLevel(){
        walls.clear();
        baggages.clear();
        destinations.clear();

        initializeBoard();
        repaint();
    }
}
